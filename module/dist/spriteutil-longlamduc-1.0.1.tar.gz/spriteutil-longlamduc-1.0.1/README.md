# Image Sprite Detection Module
## What is it?
This is a Python module used for detection sprites from an image

## Why use this module?
* **Fast:** It can detect all sprites in the image for short time
* **Easy to use:** You just need to pass an image an get the result
* **Time saving:** This module is already built so you don't need to spend time for it anymore!

## Get started